Heyo!
Parlocameon here.
This is a gift to the Hacknet Extensions Discord.
You're free to put this anywhere in your extensions if you'd like!
Even as the default!

Just make sure to give credit to Parlocameon!